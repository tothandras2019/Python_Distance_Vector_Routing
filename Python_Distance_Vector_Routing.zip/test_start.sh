#!/bin/sh

p_start(){
    python App.py -s A -d D
}

bad(){
    python App.py -s  F

    
}