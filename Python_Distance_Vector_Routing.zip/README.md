# PET PROJECT

## Distance Vector routing

### Use case

1. routing table: hálózat struktúra megadása (gráf): routerek listája: csomópontok, élek: összeköttetések listája ("A", "B", 5), JSON-file

2. forwarding table: csomag elindítása egy csomópontból: tartalmazza a forrás és célt csomópontokat -> A-ból B-be. Írja ki az útvonalat (és a távolságokat) Infinite lool elkerülése!
3. élsúly módosítása
4. él kitörlése
5. poison rivers-t támogassa: oda-vissza végtelen út.

autonóm csomópont.
tábla frissítés.

-------------------

indítás: python App.py
